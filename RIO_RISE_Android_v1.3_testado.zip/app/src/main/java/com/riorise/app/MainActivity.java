package com.riorise.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.Locale;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(8, 13, 25);
    private final int PANEL = Color.rgb(17, 26, 44);
    private static final int ACCENT = Color.rgb(35, 190, 255);
    private final int MUTED = Color.rgb(151, 169, 195);
    private LinearLayout root, content, nav;
    private SharedPreferences prefs;
    private String page = "INÍCIO";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        prefs = getSharedPreferences("riorise_settings", MODE_PRIVATE);
        buildShell();
        showPage("INÍCIO");
    }

    private void buildShell() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(dp(18), dp(18), dp(18), dp(10));
        setContentView(root);

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView brand = text("RIO RISE", 24, Color.WHITE, true);
        header.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));
        TextView version = text("v1.3  •  ANDROID", 10, ACCENT, true);
        header.addView(version);
        root.addView(header);

        TextView subtitle = text("PAINEL INDEPENDENTE", 10, MUTED, true);
        subtitle.setLetterSpacing(.14f);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.topMargin = dp(3); sp.bottomMargin = dp(18);
        root.addView(subtitle, sp);

        ScrollView scroll = new ScrollView(this);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        nav = new LinearLayout(this);
        nav.setGravity(Gravity.CENTER);
        nav.setPadding(0, dp(10), 0, 0);
        root.addView(nav);
        addNav("INÍCIO"); addNav("TREINO"); addNav("VISUAL"); addNav("AJUSTES");
    }

    private void addNav(String name) {
        TextView b = text(name, 11, MUTED, true);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(8), dp(13), dp(8), dp(13));
        b.setOnClickListener(v -> showPage(name));
        nav.addView(b, new LinearLayout.LayoutParams(0, -2, 1));
        b.setTag(name);
    }

    private void updateNav() {
        for (int i=0; i<nav.getChildCount(); i++) {
            TextView t = (TextView) nav.getChildAt(i);
            t.setTextColor(page.equals(t.getTag()) ? ACCENT : MUTED);
        }
    }

    private void showPage(String name) {
        page = name; updateNav(); content.removeAllViews();
        if (name.equals("INÍCIO")) home();
        else if (name.equals("TREINO")) training();
        else if (name.equals("VISUAL")) visual();
        else settings();
    }

    private void home() {
        card("BEM-VINDO AO RIO RISE", "Seu painel independente está pronto para configurar.");
        TextView status = text("STATUS  •  ATIVO", 12, ACCENT, true);
        status.setPadding(dp(4), dp(14), 0, dp(8)); content.addView(status);
        card("CONTROLES LOCAIS", "As opções abaixo alteram somente as preferências deste aplicativo. Elas não controlam nem modificam o jogo.");
        actionButton("ABRIR CONFIGURAÇÕES", () -> showPage("AJUSTES"));
    }


    private void training() {
        card("TREINO DE PRECISÃO", "Minijogo local para praticar reflexo e precisão. Toque nos alvos que aparecem na área abaixo.");
        final TextView score = text("PONTOS: 0     TEMPO: 30s", 14, ACCENT, true);
        score.setPadding(dp(4), dp(4), 0, dp(10));
        content.addView(score);

        final TargetTrainer trainer = new TargetTrainer(this);
        trainer.setBackground(bg(PANEL, 18));
        LinearLayout.LayoutParams gameParams = new LinearLayout.LayoutParams(-1, dp(310));
        gameParams.bottomMargin = dp(12);
        content.addView(trainer, gameParams);

        trainer.setListener((points, seconds, finished) -> {
            score.setText(finished
                ? "FIM DE JOGO  •  PONTOS: " + points
                : "PONTOS: " + points + "     TEMPO: " + seconds + "s");
        });

        actionButton("REINICIAR TREINO", trainer::start);
        TextView hint = text("Dica: tente acertar o centro dos alvos. O treino funciona totalmente offline e não interage com outros aplicativos.", 11, MUTED, false);
        hint.setPadding(dp(4), dp(2), dp(4), dp(16));
        content.addView(hint);
    }

    private static class TargetTrainer extends View {
        interface Listener { void onUpdate(int points, int seconds, boolean finished); }
        private final android.graphics.Paint paint = new android.graphics.Paint(3);
        private final android.os.Handler handler = new android.os.Handler();
        private final java.util.Random random = new java.util.Random();
        private Listener listener;
        private float targetX = 160, targetY = 160, targetR = 28;
        private int points = 0, seconds = 30;
        private boolean running = false;
        private final Runnable tick = new Runnable() {
            @Override public void run() {
                if (!running) return;
                seconds--;
                if (seconds <= 0) {
                    seconds = 0; running = false;
                    notifyListener(true);
                } else {
                    notifyListener(false);
                    handler.postDelayed(this, 1000);
                }
                invalidate();
            }
        };

        TargetTrainer(android.content.Context context) {
            super(context);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            post(this::start);
        }

        void setListener(Listener value) { listener = value; notifyListener(false); }

        void start() {
            handler.removeCallbacks(tick);
            points = 0; seconds = 30; running = true;
            moveTarget(); notifyListener(false); invalidate();
            handler.postDelayed(tick, 1000);
        }

        private void moveTarget() {
            float w = Math.max(getWidth(), 1), h = Math.max(getHeight(), 1);
            targetR = dpLocal(25);
            targetX = targetR + random.nextFloat() * Math.max(1, w - 2 * targetR);
            targetY = targetR + random.nextFloat() * Math.max(1, h - 2 * targetR);
        }

        private float dpLocal(float value) {
            return value * getResources().getDisplayMetrics().density;
        }

        private void notifyListener(boolean finished) {
            if (listener != null) listener.onUpdate(points, seconds, finished);
        }

        @Override protected void onDraw(android.graphics.Canvas canvas) {
            super.onDraw(canvas);
            paint.setColor(Color.rgb(25, 39, 61));
            canvas.drawRoundRect(0, 0, getWidth(), getHeight(), dpLocal(18), dpLocal(18), paint);
            if (running) {
                paint.setColor(ACCENT);
                canvas.drawCircle(targetX, targetY, targetR, paint);
                paint.setColor(Color.WHITE);
                canvas.drawCircle(targetX, targetY, targetR * .62f, paint);
                paint.setColor(ACCENT);
                canvas.drawCircle(targetX, targetY, targetR * .25f, paint);
            } else {
                paint.setColor(Color.WHITE);
                paint.setTextAlign(android.graphics.Paint.Align.CENTER);
                paint.setTextSize(dpLocal(15));
                String message = seconds == 0 ? "Treino finalizado" : "Preparando treino...";
                canvas.drawText(message, getWidth()/2f, getHeight()/2f, paint);
            }
        }

        @Override public boolean onTouchEvent(android.view.MotionEvent event) {
            if (event.getAction() == android.view.MotionEvent.ACTION_DOWN && running) {
                float dx = event.getX() - targetX, dy = event.getY() - targetY;
                if (dx*dx + dy*dy <= targetR*targetR) {
                    points++;
                    moveTarget();
                    notifyListener(false);
                    invalidate();
                }
                return true;
            }
            return true;
        }

        @Override protected void onDetachedFromWindow() {
            handler.removeCallbacks(tick);
            running = false;
            super.onDetachedFromWindow();
        }
    }

    private void visual() {
        card("PERSONALIZAÇÃO VISUAL", "Ajuste a aparência do painel independente.");
        switchRow("Efeito de brilho", "glow", true);
        switchRow("Animações do painel", "animations", true);
        switchRow("Mostrar indicadores", "indicators", true);
        seekRow("Intensidade do destaque", "highlight", 0, 100, 65);
        seekRow("Tamanho dos elementos", "scale", 80, 120, 100);
    }

    private void settings() {
        card("AJUSTES GERAIS", "Preferências salvas automaticamente neste aparelho.");
        switchRow("Iniciar com painel compacto", "compact", false);
        switchRow("Vibração nos controles", "vibration", true);
        switchRow("Confirmar alterações", "confirm", false);
        seekRow("Transparência do painel", "opacity", 30, 100, 95);
        actionButton("RESTAURAR PADRÕES", () -> {
            prefs.edit().clear().apply();
            Toast.makeText(this, "Configurações restauradas", Toast.LENGTH_SHORT).show();
            showPage("AJUSTES");
        });
        TextView note = text("RIO RISE • Projeto independente de interface. Sem integração com memória, rede ou controles internos de jogos.", 11, MUTED, false);
        note.setPadding(dp(4), dp(18), dp(4), dp(18)); content.addView(note);
    }

    private void card(String title, String body) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(16), dp(16), dp(16));
        box.setBackground(bg(PANEL, 18));
        TextView h = text(title, 14, Color.WHITE, true);
        TextView p = text(body, 12, MUTED, false);
        p.setLineSpacing(dp(3), 1f);
        box.addView(h);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1, -2);
        pp.topMargin = dp(8); box.addView(p, pp);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(12); content.addView(box, lp);
    }

    private void switchRow(String label, String key, boolean def) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(14), dp(12), dp(12), dp(12));
        row.setBackground(bg(PANEL, 14));
        TextView t = text(label, 13, Color.WHITE, true);
        row.addView(t, new LinearLayout.LayoutParams(0, -2, 1));
        Switch s = new Switch(this);
        s.setButtonTintList(null);
        s.setChecked(prefs.getBoolean(key, def));
        s.setOnCheckedChangeListener((button, checked) -> prefs.edit().putBoolean(key, checked).apply());
        row.addView(s);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(9); content.addView(row, lp);
    }

    private void seekRow(String label, String key, int min, int max, int def) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(14), dp(12), dp(14), dp(10));
        box.setBackground(bg(PANEL, 14));
        LinearLayout line = new LinearLayout(this);
        line.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text(label, 13, Color.WHITE, true);
        TextView value = text("", 12, ACCENT, true);
        line.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        line.addView(value);
        box.addView(line);
        SeekBar seek = new SeekBar(this);
        seek.setMax(max-min);
        seek.setProgress(Math.max(0, Math.min(max-min, prefs.getInt(key, def)-min)));
        value.setText(String.format(Locale.getDefault(), "%d", min+seek.getProgress()));
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar b, int p, boolean user) {
                int v = min+p; value.setText(String.format(Locale.getDefault(), "%d", v));
                if (user) prefs.edit().putInt(key, v).apply();
            }
            public void onStartTrackingTouch(SeekBar b) {}
            public void onStopTrackingTouch(SeekBar b) {}
        });
        box.addView(seek);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(9); content.addView(box, lp);
    }

    private void actionButton(String label, Runnable action) {
        TextView b = text(label, 12, Color.WHITE, true);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(14), dp(15), dp(14), dp(15));
        b.setBackground(bg(Color.rgb(0, 119, 180), 14));
        b.setOnClickListener(v -> action.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(4); lp.bottomMargin = dp(12); content.addView(b, lp);
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
}
