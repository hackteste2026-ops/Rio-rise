# RIO RISE — Android UI v1.2

Projeto Android independente com painel escuro, abas Início/Visual/Ajustes e preferências locais persistidas.

## O que funciona
- Navegação entre Início, Treino, Visual e Ajustes.
- Minijogo offline de precisão com alvos, pontuação e contagem regressiva de 30 segundos.
- Switches e controles deslizantes reais.
- Preferências salvas localmente com `SharedPreferences`.
- Restaurar padrões.
- Layout adaptável por densidade Android.

## Limite importante
Este app é um painel independente. Não injeta código, não lê/escreve memória de outros apps e não oferece aimbot/ESP nem integração com o jogo RioRise. Os controles ajustam somente a interface e as preferências deste app.

## Como gerar APK
1. Instale Android Studio e JDK 17.
2. Abra a pasta `RIO_RISE_Android`.
3. Aguarde a sincronização do Gradle com Android Gradle Plugin 8.6.1.
4. Instale o Android SDK 35 pelo SDK Manager.
5. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

O APK de depuração será criado em `app/build/outputs/apk/debug/`.

## Identificação
- Application ID: `com.riorise.app`
- Versão: `1.3`
- Min SDK: 23 (Android 6.0)
- Target/Compile SDK: 35
